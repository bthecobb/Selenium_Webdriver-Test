﻿using OpenQA.Selenium;
using System.Threading;
using System;
using OpenQA.Selenium.Chrome;


class EntryPoint
{
   static IWebElement textBox;
    static IWebElement textBox2;
    static IWebElement VideoName;
   static IWebElement buttonSelect;
    static IWebElement passwordBox;
    static string LoginID = " ";
    static string Password = " ";
    static void Main()
    {
        IWebDriver driver = new ChromeDriver("C:\\Users\\Brandon\\Desktop\\chromedriver_win32");

        driver.Navigate().GoToUrl("https://www.youtube.com/watch?v=Kn4btkY7I5c");

        textBox = driver.FindElement(By.Name("search_query"));
        
        Thread.Sleep(5000);
        if(textBox.Displayed)
        {
            Console.WriteLine("TextBox is here");
            textBox.SendKeys("Yu Yu hakusho ending 2" + Keys.Enter);
            Thread.Sleep(5000);  
        }
        VideoName = driver.FindElement(By.LinkText("Yu Yu Hakusho ED 2 1080p English"));
        //Thread.Sleep(5000);
        if (VideoName.Displayed)
        {
            Console.WriteLine("2nd video found");
            VideoName.Click();
            Thread.Sleep(90000);
        }
        else
        {
            Console.WriteLine("Can't see second video");
        }


        driver.Quit();

        IWebDriver driver2 = new ChromeDriver("C:\\Users\\Brandon\\Desktop\\chromedriver_win32");
        driver2.Navigate().GoToUrl("https://www.ultimateqa.com/complicated-page/");

        buttonSelect = driver2.FindElement(By.CssSelector("#et-boc > div > div > div.et_pb_row.et_pb_row_2.et_pb_row_4col > div.et_pb_column.et_pb_column_1_4.et_pb_column_2.et_pb_css_mix_blend_mode_passthrough > div.et_pb_button_module_wrapper.et_pb_button_0_wrapper.et_pb_button_alignment_left.et_pb_module > a"));

        try
        {
            buttonSelect.Click();
            Console.ForegroundColor = ConsoleColor.Blue;
            Console.WriteLine("Clicked The Button");
        }
        catch(ElementNotInteractableException)
        {
            Console.ForegroundColor =ConsoleColor.Green;
            Console.WriteLine("Element not Clickable");
        }
        Console.ForegroundColor = ConsoleColor.DarkMagenta;
        Thread.Sleep(5000);
        driver2.Quit();

        IWebDriver driver3 = new ChromeDriver("C:\\Users\\Brandon\\Desktop\\chromedriver_win32");
        driver3.Navigate().GoToUrl("https://www.twitch.tv/");

        buttonSelect = driver3.FindElement(By.CssSelector("#root > div > div.tw-flex.tw-flex-column.tw-flex-nowrap.tw-full-height > nav > div > div.tw-flex.tw-full-height.tw-mg-r-1.tw-pd-y-1 > div > div.anon-user.tw-flex.tw-flex-nowrap > div:nth-child(1) > button > div > div"));
        
       
        if (buttonSelect.Displayed)
        {
            buttonSelect.Click();
            Thread.Sleep(9000);
            textBox = driver3.FindElement(By.CssSelector("body > div.ReactModalPortal > div > div > div > div.tw-border-radius-medium.tw-flex.tw-overflow-hidden > div > div > form > div > div:nth-child(1) > div > div.tw-relative > input"));
            passwordBox = driver3.FindElement(By.CssSelector("body > div.ReactModalPortal > div > div > div > div.tw-border-radius-medium.tw-flex.tw-overflow-hidden > div > div > form > div > div:nth-child(2) > div > div:nth-child(1) > div.password-input__container.tw-relative > div.tw-relative > input"));
            if(textBox.Displayed && passwordBox.Displayed)
            {
                textBox.SendKeys(LoginID);
                passwordBox.SendKeys(Password + Keys.Enter);
                Thread.Sleep(10000);

            }
        }
        driver3.Quit();
        
        IWebDriver driver4 = new ChromeDriver("C:\\Users\\Brandon\\Desktop\\chromedriver_win32");
        driver4.Navigate().GoToUrl("https://www.twitch.tv/xstatick13");
        buttonSelect = driver4.FindElement(By.CssSelector("#root > div > div.tw-flex.tw-flex-column.tw-flex-nowrap.tw-full-height > nav > div > div.tw-flex.tw-full-height.tw-mg-r-1.tw-pd-y-1 > div > div.anon-user.tw-flex.tw-flex-nowrap > div:nth-child(1) > button > div > div"));
        
        if (buttonSelect.Displayed)
        {
            Console.ForegroundColor = ConsoleColor.DarkRed;
            Console.WriteLine("Clicked The Button");
            buttonSelect.Click();
            Thread.Sleep(9000);
            passwordBox = driver4.FindElement(By.CssSelector("body > div.ReactModalPortal > div > div > div > div.tw-border-radius-medium.tw-flex.tw-overflow-hidden > div > div > form > div > div:nth-child(2) > div > div:nth-child(1) > div.password-input__container.tw-relative > div.tw-relative > input"));
            textBox2 = driver4.FindElement(By.CssSelector("body > div.ReactModalPortal > div > div > div > div.tw-border-radius-medium.tw-flex.tw-overflow-hidden > div > div > form > div > div:nth-child(1) > div > div.tw-relative > input"));
            if (textBox2.Displayed && passwordBox.Displayed)
            {
                textBox2.SendKeys(LoginID);
                passwordBox.SendKeys(Password + Keys.Enter);
                Thread.Sleep(10000);

            }
            driver4.Quit();
        }

       
       
    }


}

